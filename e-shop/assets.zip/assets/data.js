export let products = [
  {
    title: "Product one",
    image: "./assets/product1.jpeg",
    price: "300$",
    category: "Men",
    size: "M",
  },
  {
    title: "Product two",
    image: "./assets/product2.jpeg",
    price: "440$",
    category: "Women",
    size: "L",
  },
  {
    title: "Product three",
    image: "./assets/product3.jpeg",
    price: "40$",
    category: "Kids",
    size: "S",
  },
  {
    title: "Product forth",
    image: "./assets/product4.jpeg",
    price: "300$",
    category: "Kids",
    size: "M",
  },
  {
    title: "Product five",
    image: "./assets/product5.jpeg",
    price: "4400$",
    category: "Men",
    size: "s",
  },
  {
    title: "Product six",
    image: "./assets/product6.jpeg",
    price: "100$",
    category: "Men",
    size: "s",
  },
];
